#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include<math.h>
#include<string.h>
#include "File/media.h"

int main(){
	
	scanfileuser();
	scanitem();
	scanfilegmail();
	scanfilebank();
	
	website();
	
	return 0;
}
